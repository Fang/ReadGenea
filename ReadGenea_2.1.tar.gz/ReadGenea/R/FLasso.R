#implements blockwise group fused lasso of bleakly - optimised for 1d fused lasso

#can this be done sparsely for speed?

#windowed PCA

winpca <- function( X, win = 1024, inc = floor(win/2)){
res = list()
dims = ncol(X)
    numwin <- trunc ((nrow(X) - win) / inc)
for (k in 1:dims) res[[k]] = matrix(0, dims, numwin)
res$loadings = matrix(0, dims, numwin)
st = 1
for (i in 1:numwin){
probj = prcomp(X[st:(st+win - 1),])
for (k in 1:dims){
res[[k]][,i] = probj$rot[,k]
}
res$loadings[, i] = probj$sdev
st = st + inc
}
res
}


#conduct cross validation
cv.FLasso <- function(Y, lambda = seq.log(1, 0.1, 20), K = 10, plot.it = T, relative.lambdas = T, ...){
if (length(dim(Y)) != 2) Y = matrix(Y, ncol=1)
n = nrow(Y)
if (relative.lambdas) lambda = lambda * sqrt(max(rowSums(   (  apply(scale(Y, scale=F), 2, function(t) -cumsum ( head(t, -1)) )   )^2) * n/head(as.double(1:n) * (n- as.double(1:n)), -1)))

inds = sample(1:n)
inds.orig = inds
res = NULL

for (i in 1:K){
cat("Starting fold number ", i , " / ", K, "\n")
    start.proc.time <- Sys.time()
cut = sort(inds[1:min(ceiling(n/K), length(inds))])
fitobj = FLasso(Y[-cut,] , lambda, relative.lambdas = F, mode = "fit",...)
#fitobj = rbind(fitobj[1,] , fitobj)
incl = c(0,(1:n )[-cut], n+1)
diffincl = diff(incl) - 1
Ycut = Y[cut,]
res = cbind(res,sapply(fitobj, function(t) sum((Ycut - rbind(t[1,] ,t)[ (rep(which(diffincl > 0), removeZero(diffincl)) ), ])^2)))
    end.proc.time <- Sys.time()
    cat("processing took:", format(round(as.difftime(end.proc.time - 
        start.proc.time), 3)), ".\n")
inds = tail(inds, -length(cut))
}

invisible(res)

}


FLasso <- function (Y, lambda, startpoint = NULL, trace = T, relative.lambdas = T,  mode = c("coefs", "fit"),huber = Inf){
# relative - want lambda on relative scale
# huber - threshold for huberisation as function of Y sd (Inf means no huberisation)

cumsumsh = function(t){
return(cumsum(t)[-length(t)])
}

mode = match.arg(mode)

if (length(lambda) > 1){
output = list()
ii = 1
for (i in sort(lambda, dec=T)){
if (trace) cat("## Lambda = ", i ," \n")
startpoint = FLasso(Y=Y, lambda = i, startpoint = startpoint, trace=trace, huber = huber, mode= mode, relative.lambdas = relative.lambdas)
output[[ order(lambda, decreasing=T)[ii] ]] = startpoint
ii = ii+1
}

return(invisible(output))
}

eps = 1e-2
if (length(dim(Y)) != 2) Y = matrix(Y, ncol = 1)

#might be faster to work with betad, really.
Ymeans = colMeans(Y)
p = ncol(Y)
n = as.double(nrow(Y))
Y = Y - rep(Ymeans, each = n)
huberalpha = rep(0, length(Y))

d = sqrt(n / (as.double(1:n) * (n- as.double(1:n))))[-n]#rep(1, n-1)

beta = startpoint
if (is.null(startpoint)) {
beta = Matrix(0, nrow(Y) - 1, ncol(Y))#rep(0, length(Y))
} else if (nrow(beta) == n){
beta = Matrix(apply(beta,2,diff))
}

betasparse = as.matrix(matrix(apply(beta,2, removeZero), ncol=p))

activeset = which(rowSums(abs(beta)) != 0)

C = matrix(-apply(Y[1:(n-1),, drop = F], 2, cumsum) * d, ncol = p)

if (relative.lambdas ) lambda = lambda * sqrt(max(rowSums(C^2)))
maxiter = 10000
maxiter2 = 10000
for (iter in 1:maxiter){
if (trace) cat(iter, ", A [ ", length(activeset), "] =", activeset, "\n")
for (iter2 in 1:maxiter2){
betaold = betasparse
#ivar = 1
if (length(activeset) == 0) break
activepool = 1:length(activeset)
if (length(activeset) > 1) activepool = sample(activepool)
for (var in activepool){
activevar = activeset[var]
btmp = betasparse * d[activeset]; btmp[var, ] = 0
#cumsums = scale(matrix(apply(btmp,2, cumsum), ncol = p), scale=F, center =  drop( (n-activeset) %*% btmp / n))


Svar = C[activevar,] +  d[activevar] * sum(c(  (activeset-n) %*% btmp / n, btmp) *  pmax.int( activevar - c(0,activeset), 0 ))
#Svar = C[activevar,] +  d[activevar] * colSums(rbind( -drop( (n-activeset) %*% btmp / n), btmp) *  pmax(activevar - c(0,activeset), 0 ))
#C[var,] -   d[var] *apply(   (    scale(rbind(0,apply(btmp, 2, cumsum)) ,scale=F, center= drop( ((n-1): 1) %*% btmp / n))), 2, function(t) -sum(t[1:var]) + sum(t) * var/n) 
betasparse[var,] = Svar * n/(activevar * (as.double(n) - activevar) * d[activevar]^2) *max(0, 1- lambda/sqrt(sum(Svar^2)))
#ivar = ivar +1
}
if ((max(abs(betaold - betasparse)) -> err) < eps) break
#if ((max(abs(betaold - betasparse)) -> err) < (eps * max(1, 10^(3-(iter)^(1/3) )))) break
if (trace) cat("[",iter2, ":" , err, "]")
if (maxiter2 == iter2) print ("Out of max iterations! (Inner loop)")
}
if (trace) cat("\n")
beta[activeset,] = betasparse
activeset = activeset[rowSums(abs(betasparse )) != 0]
betasparse = betasparse[rowSums(abs(betasparse )) != 0,, drop=F]

#check KKT

Ssq = replace(rowSums( (C -   d * apply( scale( apply(beta*d, 2, function(t) c(0,cumsum (t)) ), scale = F, center =  drop( ((n-1): 1) %*% (beta*(d / n)))),2, function(t) -cumsumsh(t)))^2), activeset, 0) # need a speedup
#Ssq = replace(rowSums( (C -   d * apply(( rbind(0,apply(beta*d, 2, cumsum)) - drop( ((n-1): 1) %*% (beta*(d / n)))),2, function(t) -cumsumsh(t) + sum(t) * (1:(n-1))/n))^2), activeset, 0) # need a speedup
candidate = order(Ssq, decreasing = T)[1:min(10, (n - 1 - length(activeset)))] #h(Ssq >  (lambda - eps)^2)
M  = max(Ssq) # let's add multiple simultaneously (here we add 10)

#candidate = which.max(Ssq); M = max(Ssq) # warning, this can cause possible problems in case of ties in some applications.
if (trace) cat(sqrt(M) , " -> ", lambda, "\n")

if (M >= (lambda*(1+eps))^2){
activeset = c(activeset, candidate)
betasparse = rbind(betasparse,matrix(0, length(candidate), p) )
} else {

break
}
}
if (iter == maxiter) print("Out of max iterations! (Outer loop)")
if (mode == "fit"){
obj = (scale(rbind(0,apply((beta*d),2, cumsum)), scale=F) + rep(Ymeans, each=n) )
} else {
obj = beta * d
}
 
attr(obj, "lambda") = lambda
invisible(obj)
}

